const express = require("express");
const homeController = require("./controllers/homeController");
const errorController = require("./controllers/errorController");

const layouts = require("express-ejs-layouts");

const app = express();
app.use(express.static("public"));
app.set("view engine", "ejs");
app.use(layouts);
app.set("port", process.env.PORT || 8080);
app.get("/", (req, res) => {
  res.render("index.ejs");
});

app.get("/about", homeController.showAbout);
app.get("/contact", homeController.showContact);
app.get("/events", homeController.showEvents);
app.get("/jobs", homeController.showJobs);
app.get("/index", homeController.showIndex);


app.use(errorController.pageNotFoundError);
app.use(errorController.internalServerError);
app.listen(app.get("port"), () => {
  console.log(`Server is running at http://localhost:${app.get("port")}`);
});
