exports.showAbout = (req, res) => {
  res.render("about");
};
exports.showContact = (req, res) => {
  res.render("contact");
};
exports.showEvents = (req, res) => {
  res.render("events");
};
exports.showJobs = (req, res) => {
  res.render("jobs");
};
exports.showIndex = (req, res) => {
  res.render("index");
};