const mongoose = require("mongoose");
const express = require('express');
const layouts = require("express-ejs-layouts");
const session = require('express-session')
const connectFlash = require('connect-flash')
const methodOverride = require("method-override");

const eventsController = require("./controllers/eventsController");
const jobsController = require("./controllers/jobsController");
const usersController = require("./controllers/usersController");
const homeController = require("./controllers/homeController");

const app = express();
const router = express.Router();

// Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/brandeis_saa', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

mongoose.connection.on("connected", () => {
  console.log("Connected to MongoDB");
});

mongoose.connection.on("error", (error) => {
  console.error(`MongoDB connection error: ${error}`);
});

mongoose.connection.on("disconnected", () => {
  console.log("Disconnected from MongoDB");
});

// Set up middleware
app.use(layouts);
app.use(methodOverride("_method", {
  methods: ["POST", "GET", "PUT", "DELETE"],
}));

// Set up session middleware
router.use(
  session({
    secret: "secret_passcode",
    cookie: {
      maxAge: 40000,
    },
    resave: false,
    saveUninitialized: false,
  })
);

// Set up connect-flash middleware for flash messages
router.use(connectFlash());

// Set up middleware for passing flash messages to views
router.use((req, res, next) => {
  res.locals.flashMessages = req.flash();
  next();
});

// Set up middleware for handling form data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Serve static files from the public directory
app.use(express.static("public"));

// Use the router
app.use(router);


// Routes
router.get('/', homeController.viewIndex);
router.get('/about', homeController.viewAbout);
router.get('/contact', homeController.viewContact);

// Users routes
router.get('/users', usersController.index, usersController.indexView);
router.get('/users/new', usersController.new);
router.post('/users/create', usersController.create, usersController.redirectView);
router.get('/users/:id', usersController.show, usersController.showView);
router.get('/users/:id/edit', usersController.edit);
router.put('/users/:id/update', usersController.update, usersController.redirectView);
router.delete('/users/:id/delete', usersController.delete, usersController.redirectView);

// Events routes
router.get('/events', eventsController.index, eventsController.indexView);
router.get('/events/new', eventsController.new);
router.post('/events', eventsController.create, eventsController.redirectView);
router.get('/events/:id', eventsController.show, eventsController.showView);
router.get('/events/:id/edit', eventsController.edit);
router.put('/events/:id/update', eventsController.update, eventsController.redirectView);
router.delete('/events/:id/delete', eventsController.delete, eventsController.redirectView);
router.post("/events/:id/attend", eventsController.attend);

// Jobs routes
router.get('/jobs', jobsController.index, jobsController.indexView);
router.get('/jobs/new', jobsController.new);
router.post('/jobs/create', jobsController.create, jobsController.redirectView);
router.get('/jobs/:id', jobsController.show, jobsController.showView);
router.get('/jobs/:id/edit', jobsController.edit);
router.put('/jobs/:id/update', jobsController.update, jobsController.redirectView);
router.delete('/jobs/:id/delete', jobsController.delete, jobsController.redirectView);

// Error handling
// Error handling
app.use((req, res) => {
  res.status(404).render('404', { title: '404 - Page Not Found' });
});
  
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('500', { title: '500 - Internal Server Error' });
});
  
  // Start the server
const port = process.env.PORT || 3000;
  app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

