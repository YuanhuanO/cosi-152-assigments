// Render the "about" view
exports.viewAbout = (req, res) => {
  res.render("about");
};

// Render the "contact" view
exports.viewContact = (req, res) => {
  res.render("contact");
};

// Render the "index" view
exports.viewIndex = (req, res) => {
  res.render("index");
};
