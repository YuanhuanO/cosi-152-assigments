const User = require("../models/user");

// Helper function to extract user parameters from the request body
const getUserParams = (body) => {
  return {
    name: body.name,
    email: body.email,
    password: body.password,
    role: body.role,
    graduationYear: body.graduationYear,
    major: body.major,
    job: body.job,
    company: body.company,
    city: body.city,
    state: body.state,
    country: body.country,
    zipCode: body.zipCode,
    bio: body.bio,
    interests: body.interests,
  };
};

module.exports = {
  // Fetch all users and pass them to the next middleware
  index: (req, res, next) => {
    User.find({})
      .then((users) => {
        res.locals.users = users;
        next();
      })
      .catch((error) => {
        console.log(`Error fetching users: ${error.message}`);
        next(error);
      });
  },

  // Render the users index view
  indexView: (req, res) => {
    res.render("users/index");
  },

  // Render the new user form
  new: (req, res) => {
    res.render("users/new");
  },

  // Create a new user and handle success or error scenarios
  create: (req, res, next) => {
    let userParams = getUserParams(req.body);

    User.create(userParams)
      .then((user) => {
        req.flash(
          "success",
          `${user.name} account created successfully!`
        );
        res.locals.redirect = "/users";
        res.locals.user = user;
        next();
      })
      .catch((error) => {
        console.log(`Error saving user: ${error.message}`);
        res.locals.redirect = "/users/new";
        req.flash(
          "error",
          `Failed to create account because: ${error.message}`
        );
        next();
      });
  },

  // Handle redirect to the specified path or call the next middleware
  redirectView: (req, res, next) => {
    let redirectPath = res.locals.redirect;
    if (redirectPath) res.redirect(redirectPath);
    else next();
  },

  // Fetch a user by ID and handle success or error scenarios
  show: (req, res, next) => {
    let userId = req.params.id;
    User.findById(userId)
      .then((user) => {
        if (user) {
          res.locals.user = user;
          next();
        } else {
          req.flash("error", "User not found.");
          res.locals.redirect = "/users";
          next();
        }
      })
      .catch((error) => {
        console.log(`Error fetching user by ID: ${error.message}`);
        next(error);
      });
  },

  // Render the user show view
  showView: (req, res) => {
    res.render("users/show");
  },

  // Render the edit user form
  edit: (req, res, next) => {
    let userId = req.params.id;
    User.findById(userId)
      .then((user) => {
        res.render("users/edit", {
          user: user,
        });
      })
      .catch((error) => {
        console.log(`Error fetching user by ID: ${error.message}`);
        next(error);
      });
  },

  // Update a user's information and handle success or error scenarios
  update: (req, res, next) => {
    let userId = req.params.id,
      userParams = getUserParams(req.body);
    User.findByIdAndUpdate(userId, {
      $set: userParams,
    })
      .then((user) => {
        req.flash(
            "success",
            `${user.name} account update successfully!`
          );
        res.locals.redirect = `/users/${userId}`;
        res.locals.user = user;
        next();
      })
      .catch((error) => {
        req.flash(
            "failed",
            `${user.name} account update failed!`
          );
        console.log(`Error updating user by ID: ${error.message}`);
        next(error);
      });
  },

  // Delete a user by ID and handle success or error scenarios
  delete: (req, res, next) => {
    let userId = req.params.id;
    User.findByIdAndRemove(userId)
      .then(() => {
        res.locals.redirect = "/users";
        next();
      })
      .catch((error) => {
        console.log(`Error deleting user by ID: ${error.message}`);
        next();
      });
  },
};


