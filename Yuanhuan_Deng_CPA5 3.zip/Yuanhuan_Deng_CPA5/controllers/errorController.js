// Importing the 'http-status-codes' module
const httpStatus = require("http-status-codes");

// Exporting a function to handle page not found error
exports.pageNotFoundError = (req, res) => {
  // Setting the error code to 404
  let errorCode = httpStatus.NOT_FOUND;
  
  // Setting the status code to 404
  res.status(errorCode);
  
  // Rendering the error view
  res.render("error");
};

// Exporting a function to handle internal server errors
exports.internalServerError = (error, req, res, next) => {
  // Setting the error code to 500
  let errorCode = httpStatus.INTERNAL_SERVER_ERROR;
  
  // Logging the error stack to console
  console.log(`ERROR occurred: ${error.stack}`);
  
  // Setting the status code to 500
  res.status(errorCode);
  
  // Sending a response with the error message
  res.send(`${errorCode} | Sorry, our application is taking a nap!`);
};
