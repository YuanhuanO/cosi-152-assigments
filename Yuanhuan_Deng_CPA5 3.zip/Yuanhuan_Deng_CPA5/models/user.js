const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ["student", "alumni"], default: "student" },
  graduationYear: { type: Number, required: true },
  major: { type: String, required: true },
  job: { type: String },
  company: { type: String },
  city: { type: String },
  state: { type: String },
  country: { type: String },
  zipCode: { type: Number, min: [00000, "zip code is too short!"], max: [99999, "zip code is too long!"] },
  bio: { type: String },
  interests: [{ type: String }]
});

const User = mongoose.model('User', userSchema);

module.exports = User;